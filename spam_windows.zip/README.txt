Windows compilation instructions:

1) Download and compile "boost" from boost.org. Follow instructions on the boost website (getting started) to compile. [In commandline (1) Run bootstrap.bat, and then (2) run ./bjam]
2) Download and compile "libpng", which also depends on "zlib". The libpng solution file also includes zlib project, so you just need to download zlib and place it in the directory structure explained below. Libpng readme also mentions this.

Put the compiled libraries in the following directory structure (Note that the names of the directories have been changed to remove the versioning):

./THIRDPARTY/Boost/
./THIRDPARTY/zlib/
./THIRDPARTY/libpng/

Open the SPAM.sln in visual studio and compile. Note that it has been configured only for win32 Debug and Release configurations.
